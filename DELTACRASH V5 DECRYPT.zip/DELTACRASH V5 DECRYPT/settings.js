//Ubah disini bro
//SUBSCRIBE YT : Delta Tech
global.baileys1 = require('@whiskeysockets/baileys') 
global.prefa = ['','!','.',',','⚡','🤡']
global.nocreator = ['6287739115104']
global.owner = ['6287739115184']
global.botname = 'Menhara'
global.sticker1 = "Menhara"
global.sticker2 = "Menhara"